package fr.kc.formation.templates;

import java.io.StringWriter;
import java.util.Properties;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

public class Main {

	public static void main(String... args) {

		VelocityEngine velocityEngine;
		final Properties props = new Properties();
		props.setProperty("resource.loader", "classpath");
		props.setProperty("classpath.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");

		velocityEngine = new VelocityEngine(props);
		velocityEngine.init();

		// Build a context to hold the model
		VelocityContext velocityContext = new VelocityContext();
		velocityContext.put("message", "Hello world!");
		velocityContext.put("a", 1);
		velocityContext.put("b", 2);

		// Execute the template
		StringWriter writer = new StringWriter();
		velocityEngine.mergeTemplate("template.vm", "UTF-8", velocityContext, writer);

		// Return the result
		System.out.println(writer.toString());
	}

}
