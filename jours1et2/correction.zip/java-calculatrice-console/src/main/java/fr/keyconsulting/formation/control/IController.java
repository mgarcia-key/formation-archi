package fr.keyconsulting.formation.control;

import fr.keyconsulting.formation.presentation.IPresentation;

public interface IController {
	
	public IPresentation getPresentation();
	
	public void handleException(Exception err);

}
