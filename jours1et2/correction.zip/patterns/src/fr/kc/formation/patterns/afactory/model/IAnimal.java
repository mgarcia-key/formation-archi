package fr.kc.formation.patterns.afactory.model;

public interface IAnimal {
	
	public String makeSound();
	
	public String makeMove();
	
	public default String getName() {
		return getClass().getSimpleName();
	}
	
	public default boolean canRun() {
		return false;
	}
	
	public default boolean canFly() {
		return false;
	}
	
	public default boolean canSwim() {
		return false;
	}
	
	public default String getKingdom() {
		return "Animalia";
	}
	
	public default String getPhylum() {
		return "Chordata";
	}
	
	public String getClade();
	
	public default String getClassification() {
		return getKingdom() + "-" + getPhylum() + "-" + getClade(); 
	}
	
	public default String getFullName() {
		return getClassification() + " " + getName().toUpperCase();
	}

}
