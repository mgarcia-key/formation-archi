package fr.kc.formation.patterns.singleton;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesManager {
	
	private static PropertiesManager instance = new PropertiesManager();	
	
	public static PropertiesManager getInstance() {
		return instance;
	}
	
	private Properties properties;
	
	private PropertiesManager() {
		properties = new Properties();
		
		try(InputStream is = getClass().getResourceAsStream("/application.properties")) {
			properties.load(is);
		} catch (IOException e) {
			throw new RuntimeException("Cannot load app properties", e);
		}		
	}
	
	public String getProperty(String key) {
		return properties.getProperty(key);
	}
}
