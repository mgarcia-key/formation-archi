package fr.kc.formation.patterns.afactory.factories;

import fr.kc.formation.patterns.afactory.model.IFlyingAnimal;
import fr.kc.formation.patterns.afactory.model.IRunningAnimal;
import fr.kc.formation.patterns.afactory.model.ISwimmingAnimal;
import fr.kc.formation.patterns.afactory.model.mammals.Bat;
import fr.kc.formation.patterns.afactory.model.mammals.Dog;
import fr.kc.formation.patterns.afactory.model.mammals.Dolphin;

//public class MammalsFactory implements IAnimalFactory {
public class MammalsFactory extends AFactory {
	
	@Override
	public IFlyingAnimal createFylingAnimal() {
		return new Bat();
	}

	@Override
	public IRunningAnimal createRunningAnimal() {
		return new Dog();
	}

	@Override
	public ISwimmingAnimal createSwimmingAnimal() {
		return new Dolphin();
	}

}
