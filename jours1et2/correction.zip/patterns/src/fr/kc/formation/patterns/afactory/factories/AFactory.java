package fr.kc.formation.patterns.afactory.factories;

import fr.kc.formation.patterns.afactory.model.GeologicalPeriod;

public abstract class AFactory implements IAnimalFactory {
	
	private static AFactory instance;
	
	public static void init(GeologicalPeriod period) {
		if(GeologicalPeriod.QUATERNARY.equals(period)) {
			instance = new MammalsFactory();
		} else {
			instance = new DinosaursFactory();
		}
	}
	
	public static IAnimalFactory getInstance() {
		if( instance == null ) {
			throw new IllegalStateException("Not initialized! (call init method first)");
		}
		return instance;
	}
}
