package fr.kc.formation.patterns.afactory.factories;

import fr.kc.formation.patterns.afactory.model.IFlyingAnimal;
import fr.kc.formation.patterns.afactory.model.IRunningAnimal;
import fr.kc.formation.patterns.afactory.model.ISwimmingAnimal;

public interface IAnimalFactory {
	
	public IFlyingAnimal createFylingAnimal();
	
	public IRunningAnimal createRunningAnimal();
	
	public ISwimmingAnimal createSwimmingAnimal();

}
