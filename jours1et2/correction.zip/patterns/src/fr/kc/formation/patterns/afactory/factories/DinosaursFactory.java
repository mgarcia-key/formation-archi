package fr.kc.formation.patterns.afactory.factories;

import fr.kc.formation.patterns.afactory.model.IFlyingAnimal;
import fr.kc.formation.patterns.afactory.model.IRunningAnimal;
import fr.kc.formation.patterns.afactory.model.ISwimmingAnimal;
import fr.kc.formation.patterns.afactory.model.dinos.Pliosaurus;
import fr.kc.formation.patterns.afactory.model.dinos.Pterodactyl;
import fr.kc.formation.patterns.afactory.model.dinos.TRex;


//public class DinosaursFactory implements IAnimalFactory {
public class DinosaursFactory extends AFactory {

	@Override
	public IFlyingAnimal createFylingAnimal() {
		return new Pterodactyl();
	}

	@Override
	public IRunningAnimal createRunningAnimal() {
		return new TRex();
	}

	@Override
	public ISwimmingAnimal createSwimmingAnimal() {
		return new Pliosaurus();
	}

}
