package fr.kc.formation.patterns.afactory.model.mammals;

import fr.kc.formation.patterns.afactory.model.IFlyingAnimal;

public class Bat implements IMammal, IFlyingAnimal {

	@Override
	public String makeSound() {
		return "... (ultra sonic)";
	}

}
