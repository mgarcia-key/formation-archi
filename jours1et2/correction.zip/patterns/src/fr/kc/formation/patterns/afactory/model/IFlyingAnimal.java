package fr.kc.formation.patterns.afactory.model;

public interface IFlyingAnimal extends IAnimal {

	@Override
	public default String makeMove() {
		return "I'm flying";
	}
	
	@Override
	public default boolean canFly() {
		return true;
	}


}
