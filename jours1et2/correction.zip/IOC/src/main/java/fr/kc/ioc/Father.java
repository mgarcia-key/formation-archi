package fr.kc.ioc;

public class Father {
	
	private Child child;	

	public Father(Child child) {
		super();
		this.child = child;
		System.out.println("C'tor " + getClass().getSimpleName());
	}	

	public Father() {
		this(null);
	}

	public Child getChild() {
		return child;
	}

	public void setChild(Child child) {
		this.child = child;
	}

	@Override
	public String toString() {
		return "Father [child=" + child + "]";
	}
}
