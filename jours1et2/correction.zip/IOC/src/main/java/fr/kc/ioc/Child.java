package fr.kc.ioc;

public class Child {
	
	private int age;	

	public Child(int age) {
		super();
		this.age = age;
	}

	public Child() {
		this(0);
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Child [age=" + age + "]";
	}
}
