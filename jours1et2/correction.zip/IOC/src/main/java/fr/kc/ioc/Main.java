package fr.kc.ioc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	
	public static void main(String[] args) {
		
		ApplicationContext applicationContext 
			= new ClassPathXmlApplicationContext("/spring/application-context.xml");
		
		Child child = applicationContext.getBean("child", Child.class);
		System.out.println(child);
		
		Father father = applicationContext.getBean("father", Father.class);
		System.out.println(father);		
	}
}
