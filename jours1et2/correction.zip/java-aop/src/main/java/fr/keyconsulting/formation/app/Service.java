package fr.keyconsulting.formation.app;

public class Service {
	
	public void operationOne() {
		System.out.println("call operationOne");
	}
	
	public void operationTwo() {
		System.out.println("call operationTwo");
	}
	
	public void operationThree() {
		System.out.println("call operationThree");
	}

}
