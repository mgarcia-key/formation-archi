package fr.keyconsulting.formation.plugins.impl;

import fr.keyconsulting.formation.plugins.IPlugin;

public class PluginOne implements IPlugin {

}
