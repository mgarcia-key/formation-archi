package fr.keyconsulting.formation.plugins;

import java.io.File;
import java.io.InputStream;
import java.lang.reflect.Proxy;
import java.util.Properties;
import java.util.Scanner;

import fr.keyconsulting.formation.plugins.dynamic.PluginClassLoader;
import fr.keyconsulting.formation.plugins.proxy.LogInvocationHandler;

public class MainDynamic {
	
	public static void main(String... args) throws Exception {
		Properties appProps = new Properties();
		try( InputStream is = MainDynamic.class.getResourceAsStream("/application.properties") ) {			
			appProps.load(is);
		}
		
		String implClassName = appProps.getProperty("plugin.impl.class");
		
		ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
		
		Class<?> clazz = contextClassLoader.loadClass(implClassName);
		IPlugin plugin = (IPlugin) clazz.newInstance();	
		plugin = getProxy(contextClassLoader, plugin);
		executePlugin(plugin);
		
		File binFolder = new File(MainDynamic.class.getResource("/").getFile());		
		
		//TODO 1 : pause
		System.out.println("Entrer 'yes' when ready");
		Scanner input = new Scanner(System.in);
		input.next();
		input.close();
						
		clazz = reload(implClassName, contextClassLoader, binFolder);
		
		IPlugin reloadedPlugin = (IPlugin) clazz.newInstance();			
		executePlugin(reloadedPlugin);
		
		System.out.println("Ok.");
	}
	
	private static IPlugin getProxy(ClassLoader classLoader, IPlugin plugin) {
		Class<?>[] interfaces = new Class<?>[] { IPlugin.class};
		return (IPlugin) Proxy.newProxyInstance(classLoader, interfaces, new LogInvocationHandler(plugin));
	}

	private static Class<?> reload(String implClassName, ClassLoader contextClassLoader, File binFolder)
			throws ClassNotFoundException {
		return new PluginClassLoader(contextClassLoader, binFolder).loadClass(implClassName);
	}

	private static void executePlugin(IPlugin plugin) {
		System.out.println(plugin.getName() + ": ");
		plugin.doSomething();
	}

}
