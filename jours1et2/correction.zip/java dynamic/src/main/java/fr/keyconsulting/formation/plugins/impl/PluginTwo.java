package fr.keyconsulting.formation.plugins.impl;

import fr.keyconsulting.formation.plugins.IPlugin;

public class PluginTwo implements IPlugin {
	
	/*
	public void doSomething() {
		System.out.println("Something else");		
	}*/
}
