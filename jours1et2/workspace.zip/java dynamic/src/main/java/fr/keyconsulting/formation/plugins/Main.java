package fr.keyconsulting.formation.plugins;

import java.io.InputStream;
import java.util.Properties;

public class Main {
	

	

}
