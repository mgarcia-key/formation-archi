package fr.keyconsulting.formation.plugins.dynamic;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

public class PluginClassLoader extends ClassLoader {
	
	private File binFolder;

	public PluginClassLoader(ClassLoader parent, File binFolder) {
		super(parent);
		this.binFolder = binFolder;
	}

	public Class<?> loadClass(String fullClassName) throws ClassNotFoundException {

		Class<?> clazz;
		
		if (!fullClassName.startsWith("fr.keyconsulting.formation.plugins")) {
			clazz = super.loadClass(fullClassName);
		} 
		else {
			try {
				File binaryFile = getBinaryFileForClass(binFolder, fullClassName);
				clazz = null; //<-- TODO : load class form its binary file
			} catch (Exception e) {
				throw new ClassNotFoundException(fullClassName, e);			
			}
		}
		return clazz;
	}
	
	private File getBinaryFileForClass(File folder, String fullClassName) {
		return new File(folder, fullClassName.replace(".", "/") + ".class");		
	}

	private Class<?> loadClassFromFile(String fullClassName, File binaryClassFile) throws MalformedURLException, IOException, ClassFormatError {
		final URL binaryClassURL = asURL(binaryClassFile);
		return loadClassFromFile(fullClassName, binaryClassURL);
	}
	
	private Class<?> loadClassFromFile(String fullClassName, URL binaryClassURL) throws MalformedURLException, IOException, ClassFormatError {
		Class<?> clazz;
		try (
			// try-with-resources (since Java 7) 
			InputStream input = new BufferedInputStream(binaryClassURL.openStream());				
		) {
			ByteArrayOutputStream buffer = new ByteArrayOutputStream();
			int data = input.read();
			while (data != -1) {
				buffer.write(data);
				data = input.read();
			}
			byte[] classData = buffer.toByteArray();
			clazz = defineClass(fullClassName, classData, 0, classData.length);
		}
		return clazz;
	}

	@SuppressWarnings("deprecation")
	private URL asURL(File file) throws MalformedURLException {
		// Bug workaround : file.toURI().toURL().openStream()
		// make FileUrlConnection throws FileNotFoundException with paths containing white spaces 
		// (due to %20 encoding) 
		return file.toURL(); 
	}

}
