#!/bin/bash
export CATALINA_HOME=`pwd`
export JAVA_HOME="$CATALINA_HOME/jdk7-lin"
export JRE_HOME="$CATALINA_HOME/jdk7-lin"
