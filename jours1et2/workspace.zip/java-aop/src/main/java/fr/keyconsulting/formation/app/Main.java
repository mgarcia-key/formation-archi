package fr.keyconsulting.formation.app;

public class Main {
	
	public static void main(String... args) {
		Service service = new Service();
		service.operationOne();
		service.operationTwo();
		service.operationThree();
	}

}
