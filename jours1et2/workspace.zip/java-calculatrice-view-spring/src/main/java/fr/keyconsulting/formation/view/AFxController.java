package fr.keyconsulting.formation.view;

import fr.keyconsulting.formation.control.IController;

public class AFxController<C extends IController> extends AView<C> {
	
}
