package fr.keyconsulting.formation.factory;

import fr.keyconsulting.formation.control.app.IApplicationCtrl;
import fr.keyconsulting.formation.control.app.GUIApplicationCtrl;
import fr.keyconsulting.formation.control.calc.ICalculCtrl;
import fr.keyconsulting.formation.control.calc.GUICalculCtrl;

public class GUIControllersFactory extends AFactory {
	
	@Override
	public IApplicationCtrl createApplication() {
		return null; //TODO	call GUIApplicationCtrl constructor
	}
	
	@Override
	public ICalculCtrl createCalcul(IApplicationCtrl parent) {
		return null; //TODO call GUICalculCtrl constructor
	}

}
