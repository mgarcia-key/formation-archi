package fr.kc.formation.patterns.afactory.model.mammals;

import fr.kc.formation.patterns.afactory.model.ISwimmingAnimal;

public class Dolphin implements IMammal, ISwimmingAnimal {

	@Override
	public String makeSound() {
		return "fiiiip, fiiiip, fiiiip!";
	}

}
