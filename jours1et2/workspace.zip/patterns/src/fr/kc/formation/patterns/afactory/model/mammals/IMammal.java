package fr.kc.formation.patterns.afactory.model.mammals;

import fr.kc.formation.patterns.afactory.model.IAnimal;

public interface IMammal extends IAnimal {

	@Override
	public default String getClade() {
		return "Mammalia";
	}
	
	

}
