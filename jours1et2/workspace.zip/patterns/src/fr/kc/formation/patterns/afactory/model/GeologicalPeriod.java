package fr.kc.formation.patterns.afactory.model;

public enum GeologicalPeriod {
	
	JURASSIC, QUATERNARY

}
