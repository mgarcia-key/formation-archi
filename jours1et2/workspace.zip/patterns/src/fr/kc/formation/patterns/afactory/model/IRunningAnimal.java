package fr.kc.formation.patterns.afactory.model;

public interface IRunningAnimal extends IAnimal {

	@Override
	default String makeMove() {
		return "I'm running";
	}

	@Override
	default boolean canRun() {
		return true;
	}	

}
