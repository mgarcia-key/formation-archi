package fr.kc.formation.patterns.afactory.model.dinos;

import fr.kc.formation.patterns.afactory.model.IRunningAnimal;

public class TRex implements IDinosaur, IRunningAnimal {

	@Override
	public String makeSound() {
		return "ROOAAAAR!";
	}	

}
