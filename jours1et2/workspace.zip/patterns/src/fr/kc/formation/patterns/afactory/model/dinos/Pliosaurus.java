package fr.kc.formation.patterns.afactory.model.dinos;

import fr.kc.formation.patterns.afactory.model.ISwimmingAnimal;

public class Pliosaurus implements IDinosaur, ISwimmingAnimal {

	@Override
	public String makeSound() {
		return "swooch, swooch";
	}

}
