package fr.kc.formation.patterns;

import fr.kc.formation.patterns.afactory.model.GeologicalPeriod;
import fr.kc.formation.patterns.afactory.model.IAnimal;
import fr.kc.formation.patterns.afactory.model.IFlyingAnimal;
import fr.kc.formation.patterns.afactory.model.IRunningAnimal;
import fr.kc.formation.patterns.afactory.model.ISwimmingAnimal;
import fr.kc.formation.patterns.afactory.model.dinos.Pliosaurus;
import fr.kc.formation.patterns.afactory.model.dinos.Pterodactyl;
import fr.kc.formation.patterns.afactory.model.dinos.TRex;

public class Main {
	
	public static void main(String... args) {		
		Main program = new Main();
		program.start();		
	}
	
	private Main() {
		this(GeologicalPeriod.JURASSIC);
	}

	private GeologicalPeriod period;
	
	private Main(GeologicalPeriod period) {
		super();
		this.period = period;
	}
	
	private void start() {		
		
		IFlyingAnimal flying = new Pterodactyl();
		IRunningAnimal running =  new TRex();
		ISwimmingAnimal swimming =  new Pliosaurus();
		
		System.out.println("Period: " + period);
		System.out.println();
		
		display("flying:   ", flying);
		display("running:  ", running);
		display("swimming: ", swimming);
		
		System.out.println("Ok.");
	}	
	
	private void display(String label, IAnimal animal) {
		System.out.println(label + animal.getFullName());
		System.out.println("move:     " + animal.makeMove());
		System.out.println("sound:    '" + animal.makeSound() + "'");
		System.out.println("can swim: " + toStr(animal.canSwim()));
		System.out.println("can run:  " + toStr(animal.canRun()));
		System.out.println("can fly:  " + toStr(animal.canFly()));
		System.out.println();
	}
	
	private String toStr(boolean bool) {
		return bool ? "yes" : "no";
	}

}
