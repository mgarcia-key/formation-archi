package fr.kc.formation.patterns.afactory.model;

public interface ISwimmingAnimal extends IAnimal {
	
	@Override
	public default String makeMove() {
		return "I'm swimming";
	}

	@Override
	default boolean canSwim() {
		return true;
	}
	
}
