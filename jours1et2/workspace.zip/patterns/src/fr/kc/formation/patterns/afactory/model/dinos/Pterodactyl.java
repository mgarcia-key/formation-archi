package fr.kc.formation.patterns.afactory.model.dinos;

import fr.kc.formation.patterns.afactory.model.IFlyingAnimal;

public class Pterodactyl implements IDinosaur, IFlyingAnimal{

	@Override
	public String makeSound() {
		return "iark, iark iark!";
	}

}
