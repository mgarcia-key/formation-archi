package fr.kc.formation.patterns.afactory.model.mammals;

import fr.kc.formation.patterns.afactory.model.IRunningAnimal;

public class Dog implements IMammal, IRunningAnimal {

	@Override
	public String makeSound() {
		return "Arf Arf!";
	}

	@Override
	public boolean canSwim() {
		return true;
	}	

}
