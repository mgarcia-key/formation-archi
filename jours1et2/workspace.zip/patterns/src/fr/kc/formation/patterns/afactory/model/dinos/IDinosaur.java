package fr.kc.formation.patterns.afactory.model.dinos;

import fr.kc.formation.patterns.afactory.model.IAnimal;

public interface IDinosaur extends IAnimal {

	@Override
	default String getClade() {
		return "Dinosaur";
	}	

}
